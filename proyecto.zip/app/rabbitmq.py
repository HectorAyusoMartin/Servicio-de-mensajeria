"""

Integración con rabbitMQ

"""