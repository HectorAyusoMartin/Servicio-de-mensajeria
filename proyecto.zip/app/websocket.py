"""

Lógica para el manejo de  websockets

"""