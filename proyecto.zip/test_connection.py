import asyncio
from app.db import database

async def test_connection():
    
    # Listamos colecciones existentes en la base de datos "Chat_app"
    collections = await database.list_collection_names()
    print("Colecciones en la base de datos:",collections)
    
    
if __name__ == "__main__":
    
    asyncio.run(test_connection())
    # Conexion establecida con exito